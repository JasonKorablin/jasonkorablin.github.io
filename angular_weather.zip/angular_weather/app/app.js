angular
	.module('app', [
		'weather',
		'search'
	]);